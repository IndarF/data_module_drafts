OK_FORMAT = True

test = {   'name': 'q11',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(sorted_list, list)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(sorted_list) == 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> sorted_list == ['hats', 'jackets', 'pants', 'shirts', 'shorts']\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
