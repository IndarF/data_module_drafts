OK_FORMAT = True

test = {   'name': 'q3',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> type(answer_3) == type('word')\nTrue", 'hidden': False, 'locked': False}, {'code': ">>> answer_3 == '3'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
