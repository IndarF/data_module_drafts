OK_FORMAT = True

test = {   'name': 'q4',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> type(answer_4) == type('word')\nTrue", 'hidden': False, 'locked': False}, {'code': ">>> answer_4 == '1'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
