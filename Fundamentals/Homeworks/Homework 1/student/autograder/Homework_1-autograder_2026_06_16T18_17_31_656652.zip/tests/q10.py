OK_FORMAT = True

test = {   'name': 'q10',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> isinstance(total, int)\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> total == 21\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
