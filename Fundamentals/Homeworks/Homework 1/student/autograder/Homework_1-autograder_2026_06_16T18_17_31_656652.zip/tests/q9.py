OK_FORMAT = True

test = {   'name': 'q9',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(inventory, list)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(inventory) == 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> inventory == [7, 4, 2, 5, 3]\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
