OK_FORMAT = True

test = {   'name': 'q8',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(clothes, list)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(clothes) == 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> clothes == ['shirts', 'pants', 'shorts', 'jackets', 'hats']\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
