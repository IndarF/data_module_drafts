OK_FORMAT = True

test = {   'name': 'q13',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> type(sbomb_mean) == float\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> sbomb_mean - 22.77 < 0.0001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
