OK_FORMAT = True

test = {   'name': 'q12',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(dessert_mean) == float\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> dessert_mean - 20.2 < 0.0001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
