OK_FORMAT = True

test = {   'name': 'q7',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(bed_mean_LA) == float\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bed_mean_LA - 5466 / 18 < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
