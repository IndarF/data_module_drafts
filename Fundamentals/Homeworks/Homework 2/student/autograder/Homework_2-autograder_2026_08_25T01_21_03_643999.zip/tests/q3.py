OK_FORMAT = True

test = {   'name': 'q3',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(staffed_beds_LA) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> staffed_beds_LA - 5466 < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
