OK_FORMAT = True

test = {   'name': 'q8',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(bed_mean_SF) == np.float64\nFalse', 'hidden': False, 'locked': False},
                                   {'code': '>>> bed_mean_SF - 3371 / 13 < 0.0001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
