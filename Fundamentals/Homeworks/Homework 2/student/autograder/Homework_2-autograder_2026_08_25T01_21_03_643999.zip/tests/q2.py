OK_FORMAT = True

test = {   'name': 'q2',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(staffed_beds_SF) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> staffed_beds_SF - 3371 < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
