OK_FORMAT = True

test = {   'name': 'q5',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(staffed_beds_LA) == np.int64\nFalse', 'hidden': False, 'locked': False},
                                   {'code': '>>> staffed_beds_LA - 5466 < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
