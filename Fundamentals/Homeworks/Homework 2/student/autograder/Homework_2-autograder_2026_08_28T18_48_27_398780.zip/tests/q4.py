OK_FORMAT = True

test = {   'name': 'q4',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(bed_npsum_SF) == np.int64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bed_npsum_SF - 3371 < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
