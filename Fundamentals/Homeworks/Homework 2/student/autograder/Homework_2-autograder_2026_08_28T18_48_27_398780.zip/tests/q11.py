OK_FORMAT = True

test = {   'name': 'q11',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(bed_sd_SF) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bed_sd_LA - 270.5451433 < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
