OK_FORMAT = True

test = {   'name': 'q5',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(bed_npsum_LA) == np.int64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bed_npsum_LA - 5466 < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
