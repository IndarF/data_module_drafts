OK_FORMAT = True

test = {   'name': 'q10',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(bed_sd_LA) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bed_sd_LA - 231.2812141 < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
