OK_FORMAT = True

test = {   'name': 'q12',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(bed_median_SF) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bed_median_SF - 209 < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
