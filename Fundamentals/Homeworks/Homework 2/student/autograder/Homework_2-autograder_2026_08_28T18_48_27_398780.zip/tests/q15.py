OK_FORMAT = True

test = {   'name': 'q15',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(bed_median_LA) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bed_median_LA - 316.5 < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
