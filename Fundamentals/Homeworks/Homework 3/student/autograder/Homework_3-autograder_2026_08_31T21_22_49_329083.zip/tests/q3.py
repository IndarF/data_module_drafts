OK_FORMAT = True

test = {   'name': 'q3',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(total_discharges_SF) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> total_discharges_SF - pd.read_csv('Hospitals_SF.csv', sep=',')['Total_Discharges'].sum() < 1e-05\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
