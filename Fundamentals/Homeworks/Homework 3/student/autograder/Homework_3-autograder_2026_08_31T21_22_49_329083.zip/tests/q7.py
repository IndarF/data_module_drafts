OK_FORMAT = True

test = {   'name': 'q7',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(mean_gpr_SF) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> mean_gpr_SF - pd.read_csv('Hospitals_SF.csv', sep=',')['Gross_Patient_Revenue'].mean() < 1e-05\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
