OK_FORMAT = True

test = {   'name': 'q6',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(gpr_LA) == np.int64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> gpr_LA - pd.read_csv('Hospitals_LA.csv', sep=',')['Gross_Patient_Revenue'].sum() < 1e-05\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
