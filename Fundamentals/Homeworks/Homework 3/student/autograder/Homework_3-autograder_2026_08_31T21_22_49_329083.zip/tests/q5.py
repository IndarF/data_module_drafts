OK_FORMAT = True

test = {   'name': 'q5',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(gpr_SF) == np.int64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> gpr_SF - pd.read_csv('Hospitals_SF.csv', sep=',')['Gross_Patient_Revenue'].sum() < 1e-05\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
