OK_FORMAT = True

test = {   'name': 'q9',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(median_gpr_SF) == float\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> median_gpr_SF - pd.read_csv('Hospitals_SF.csv', sep=',')['Gross_Patient_Revenue'].median() < 1e-05\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
