OK_FORMAT = True

test = {   'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(staffed_beds_SF) == np.int64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> staffed_beds_SF - pd.read_csv('Hospitals_SF.csv', sep=',')['Staffed_Beds'].sum() < 1e-05\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
