OK_FORMAT = True

test = {   'name': 'q8',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(mean_gpr_LA) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> mean_gpr_LA - pd.read_csv('Hospitals_LA.csv', sep=',')['Gross_Patient_Revenue'].mean() < 1e-05\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
