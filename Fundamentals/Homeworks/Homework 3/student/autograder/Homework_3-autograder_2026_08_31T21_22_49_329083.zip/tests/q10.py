OK_FORMAT = True

test = {   'name': 'q10',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(median_gpr_LA) == float\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> median_gpr_LA - pd.read_csv('Hospitals_LA.csv', sep=',')['Gross_Patient_Revenue'].median() < 1e-05\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
