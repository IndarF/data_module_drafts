OK_FORMAT = True

test = {   'name': 'q4',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(total_discharges_LA) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> total_discharges_LA - pd.read_csv('Hospitals_LA.csv', sep=',')['Total_Discharges'].sum() < 1e-05\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
