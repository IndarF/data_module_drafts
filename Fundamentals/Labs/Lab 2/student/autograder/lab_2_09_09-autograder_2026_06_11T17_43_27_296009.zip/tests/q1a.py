OK_FORMAT = True

test = {   'name': 'q1a',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> def say_hello():\n...     print('Hello, World!')\n>>> say_hello()\nHello, World!\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
