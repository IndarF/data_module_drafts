OK_FORMAT = True

test = {   'name': 'ex1',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(mean) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> mean - (25 + 34 + 100 + 900 + 200 + 50) / 6 < 0.0001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
