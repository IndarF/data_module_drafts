OK_FORMAT = True

test = {   'name': 'ex5',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(sbomb_mean) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sbomb_mean - np.mean(sugar_bomb) < 0.0001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
