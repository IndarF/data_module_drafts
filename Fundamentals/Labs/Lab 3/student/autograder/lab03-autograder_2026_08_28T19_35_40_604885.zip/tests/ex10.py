OK_FORMAT = True

test = {   'name': 'ex10',
    'points': 2,
    'suites': [{'cases': [{'code': '>>> sbomb_median - 20.0 < 1e-05\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
