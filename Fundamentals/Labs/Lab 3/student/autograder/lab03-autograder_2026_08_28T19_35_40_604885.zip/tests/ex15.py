OK_FORMAT = True

test = {   'name': 'ex15',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(sbomb_std) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sbomb_std - np.std(sugar_bomb) < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
