OK_FORMAT = True

test = {'name': 'ex9', 'points': 2, 'suites': [{'cases': [{'code': '>>> median - 42.0 < 1e-05\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
