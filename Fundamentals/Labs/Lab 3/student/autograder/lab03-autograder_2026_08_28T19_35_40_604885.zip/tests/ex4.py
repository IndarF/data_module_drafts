OK_FORMAT = True

test = {   'name': 'ex4',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(dessert_mean) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> dessert_mean - 19.5 < 0.0001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
