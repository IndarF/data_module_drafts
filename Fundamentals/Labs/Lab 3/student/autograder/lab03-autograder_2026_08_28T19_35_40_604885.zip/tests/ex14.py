OK_FORMAT = True

test = {   'name': 'ex14',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(sample_std) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sample_std - np.std([25, 34, 1000, 200, 50]) < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
