OK_FORMAT = True

test = {   'name': 'ex2',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(mean) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> mean - (25 + 34 + 100 + 900 + 200 + 50 + 987 + 1500) / 8 < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
