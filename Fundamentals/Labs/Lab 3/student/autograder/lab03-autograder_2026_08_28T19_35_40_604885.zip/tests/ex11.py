OK_FORMAT = True

test = {   'name': 'ex11',
    'points': 2,
    'suites': [{'cases': [{'code': '>>> dessert_median - 20.0 < 1e-05\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
