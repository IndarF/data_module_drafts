OK_FORMAT = True

test = {   'name': 'ex1',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(sample_sum) == np.int64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sample_sum - np.sum([25, 34, 100, 900, 200, 50]) < 0.0001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
