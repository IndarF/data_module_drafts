OK_FORMAT = True

test = {   'name': 'ex1',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(data_frame) == pd.core.frame.DataFrame\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(data_frame) == 30\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
