OK_FORMAT = True

test = {   'name': 'ex3',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(data_frame) == pd.core.frame.DataFrame\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> sum_grams_of_fat - data_frame['Grams of Fat'].sum() < 0.0001\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
