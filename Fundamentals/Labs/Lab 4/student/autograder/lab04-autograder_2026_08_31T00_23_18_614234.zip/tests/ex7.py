OK_FORMAT = True

test = {   'name': 'ex7',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(data_frame) == pd.core.frame.DataFrame\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> median_grams_of_fat - data_frame['Grams of Fat'].median() < 1e-05\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
