OK_FORMAT = True

test = {   'name': 'ex12',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> type(data_frame) == pd.core.frame.DataFrame\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> median_grams_of_sugar - data_frame['Grams of Sugar'].median() < 1e-05\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
